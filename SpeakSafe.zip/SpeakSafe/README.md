# SpeakSafe (hackathon prototype)

A private, mobile-first site for students and staff who are being abused sexually, verbally or online:
report it, keep a private journal, and know your rights. Built to be offered to institutions (first: Rosebank College).
Plain HTML, CSS and JavaScript. No build step, no frameworks, no server.

```
SpeakSafe
|-- html   all pages (wellness.html is the Student Wellness tool)
|-- css    style.css
|-- js     all scripts (config.js = everything an institution changes)
|-- tools  demo-wellness-private-key.pem (DEMO ONLY, see below)
```

## Run it in VS Code

1. Open the **SpeakSafe** folder in VS Code (File > Open Folder).
2. Install the **Live Server** extension (Ritwick Dey).
3. Right-click `html/index.html` and choose **Open with Live Server**.

Use `localhost` or `https`. On a plain `http://192.168...` address the browser switches off the encryption
SpeakSafe depends on, so sign-in is blocked and the page says why.

## Who can use it, and the login

Only **students and staff** of the institution. Set the institution in `js/config.js` > `institution`:
its name, the serial-code prefix, and the number format for each group, for example Rosebank students
`ST` + digits (`^ST\d{4,10}$`). Another institution only changes this block.

**The login asks for only two things: the student/staff number and a password.**
- The number's format decides whether the person is a student or staff (students are checked first).
- First time on a device, typing a new valid number reveals a "type the password again" box. After that it is a
  normal sign-in. Nothing else is asked: no name, no phone. Student Wellness finds those from the number in the
  institution's own records.
- The account holds only the number, role and institution, **locked (AES-GCM) with a key made from number +
  password** (PBKDF2, 200,000 rounds). The key lives in the open tab only and is wiped by EXIT / sign out.
  After 5 wrong tries the button waits 30 seconds.
- The **journal (text and photos) is encrypted with the same key.** It cannot be read without signing in, even by
  someone who opens the browser's storage.
- A forgotten password cannot be recovered (nothing is on a server). The page offers to erase and start again.
- Needs `https` or `localhost` (browser encryption). Otherwise sign-in is blocked.

**Prototype limits, say these to the institution:**
- The login checks the number's *format* only. It cannot prove the person really is a student or staff member.
  The student format (`ST` + digits) is fairly tight, but the **staff format in `config.js` is a generic placeholder
  that accepts almost any letters and numbers**, so tighten it to the institution's real staff format. For real
  verification the institution connects its own directory or single sign-on, or supplies a list of valid numbers.
- Accounts and journals live in one browser on one device (no sync between devices).

## Reports, serial codes and Student Wellness

Students and staff both report to **Student Wellness** (`js/config.js` > `roles` / `recipients`).

1. The form asks: kind of abuse (sexual / verbal / online / something else, optional), where, date, time,
   what happened, photos (optional), and one tick: "Student Wellness can identify me with my serial code".
2. **Send my report** makes a **serial code** (like `RB-7K3M-9QX2`) and **sends the report automatically** (below).
   The person sees the serial code and can download a PDF copy.
3. The report holds the person's identity only as a **sealed identity code** (`SW1...`) containing their
   student/staff number, role and institution. It is sealed with Student Wellness' **public key** (RSA-OAEP wraps
   an AES-GCM key). **Only Student Wellness' private key can open it.** To everyone else the report shows only the
   serial code.
4. Student Wellness opens `html/wellness.html`, adds their private key, pastes the identity code (or the whole
   email) and sees the serial code, role, number and institution. They look the number up in the institution's
   own records for the rest, and use the serial code instead of the name in notes and messages. The person can
   quote the serial code to ask for an update, and sees their past serial codes on the Report page (kept locked:
   code, date, kind only).

### Automatic sending (temporary: goes to the developer's email)

`recipients.wellness.email` in `config.js` is currently **maqinasesokabo@gmail.com**. With `delivery.auto: true`
the report is posted to the free **FormSubmit** service (formsubmit.co), which forwards it to that address, with a
PDF copy attached. If the attachment is refused it sends the text alone. If sending fails, the person sees a
"could not send" screen with **Try again**, **Download as PDF** and **Open email instead**. No message ever says
"sent" unless the service accepted it.

- **One-time activation:** the first report sent to an address makes FormSubmit email that address a confirmation
  link. Click it once. Send a test report, activate, then send another. (Not tested against the live service,
  because the build environment cannot reach it. Test it yourself before the demo.)
- **When Student Wellness' email is known:** change that one `email` line (it must be activated once too).
- **Privacy trade-off:** the report text and PDF pass through FormSubmit and sit in a Gmail inbox. The student's
  identity does not (it is sealed), but the abuse description does. This is fine for a hackathon demo, **not for a
  real institution.** For real use, set `delivery.endpoint` to the institution's own server (accepts a
  `multipart/form-data` POST with the fields in `report.js` and replies `{"success": true}`), which stores reports
  and gives Wellness a case list and a way to reply by serial code.
- The email address is visible in the page code (anyone can see where reports go). FormSubmit can give a hidden
  alias address after activation; use that in `endpoint` if you want it hidden.

**Keys.** `config.js` ships a **DEMO public key**; its private key is in `tools/demo-wellness-private-key.pem`.
Anyone with that file can open demo reports. Before real use, Student Wellness makes their own pair on
`wellness.html` ("First time?"), keeps the private key safe (and backed up), and the new public key goes in
`config.js` > `wellnessPublicKey`. Delete the demo key file. Host `wellness.html` where only Wellness staff reach it.

## EXIT button

Unchanged: the red EXIT button (and Esc) blanks the page, signs you out, and replaces the current
history entry with `html/weather.html`. It does **not** delete browser history, saved journal
entries or other traces. Pressing Back can still return to an earlier SpeakSafe page (which then
asks for sign-in again). People at risk should also clear history or use a private window.

## Photos and screenshots (report and journal only)

Users can paste an image into the text box (Ctrl+V) or press "Choose Files" (this works on phones,
where pasting images is unreliable). Report: up to 3 images. Journal: up to 5 per entry. No other page accepts images.

- Every image is redrawn and re-saved as a JPEG (max 1280px). This shrinks it and removes hidden
  photo details such as GPS location and camera info (EXIF). Original file names are never kept or sent.
- Journal photos are encrypted with the login key and stored in this browser (IndexedDB). Deleting an entry,
  "Erase all", or "Erase everything" on the sign-in page removes them too.
- Report photos are never stored on the device. They go only into the PDF that is sent and the PDF copy the person can download.
- The downloaded journal .txt lists entries but does not include photos.
- A photo can still identify someone through what it shows (faces, names, places). The page warns about this.

## Privacy: what we can and cannot say

- The report is **private to everyone except Student Wellness**, who can identify the person with the serial code.
  The person is told this and must tick to agree. It is not anonymous to Student Wellness.
- While reports go through FormSubmit to a Gmail inbox, the description of what happened is visible to those
  services (see above). The identity is not.
- Report text and photos are never stored on the device. Only serial code, date and kind are kept, locked.
- A serial code is not secret from whoever the person shows it to, and the PDF is an ordinary file.
- Downloaded journal .txt files are ordinary files, not protected by the login.
- Anyone who learns the person's number and password can open their journal. Tell people to use EXIT and to
  sign out on shared devices. EXIT does not erase browser history.

## Contacts and legal information

Helpline numbers and the main legal statements were checked against government and organisation
websites on 27 October 2026 (GBV Command Centre, Stop Gender Violence, LifeLine, SADAG, Childline,
Legal Aid SA; the Employment Equity Act harassment rules and 2022 Code; the CCMA six-month limit (for staff);
the DHET GBV policy framework; PEP within 72 hours; Thuthuzela Care Centres). Not re-verified:
the Domestic Violence Act / Protection from Harassment Act summaries and "court clerks can help
with forms". Services can change or go offline (the GBV Command Centre line was out of service in
2024 and restored in December 2024), so re-check before launch and have a GBV or legal
professional review the content.

## Testing done

34 automated checks in headless Chromium against the site served locally, with the FormSubmit address mocked:
number-format rules, new-account and sign-in modes, wrong password, no readable number/journal text in storage,
encrypted journal and photos still readable after sign-in, consent tick, automatic send (one request, right
fields, PDF attached, no student number in it), attachment-refused fallback, failure screen, retry, email
fallback, the Wellness page opening the sealed identity for a student and a staff member, EXIT.
**Not tested:** the real FormSubmit service (no network access from the build environment), Gmail delivery,
Safari/iOS, Firefox, real phones, screen readers, how each email app handles the `mailto:` fallback, the 30-second
lockout ending, very large photo libraries, HEIC photos on browsers that cannot decode them (these show an
error), and any real institution directory or backend (none exists yet).
