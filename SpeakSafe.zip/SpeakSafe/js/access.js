/* Sign-in page for students and staff of the institution set in config.js.
   Asks ONLY for the student/staff number and a password.
   - The number must match the institution's format (students: ST + numbers). The format also tells us whether the
     person is a student or staff member.
   - First time on a device the page asks for the password twice. The account holds only the number, role and
     institution, locked (AES-GCM) with a key made from number + password. Student Wellness finds everything else
     about the person from the number, in the institution's own records.
   PROTOTYPE LIMIT: this checks the number's FORMAT only. It cannot prove the person really is a student or staff
   member. That needs the institution's own directory or single sign-on (see README). */
(function () {
  "use strict";
  if (!window.SS) { return; }
  var SS = window.SS, V = SS.vault;
  var INST = (SS.config && SS.config.institution) || {};

  var params = new URLSearchParams(window.location.search);
  var next = params.get("next") || "index.html";
  if (!/^[a-z]+\.html$/i.test(next) || next === "access.html") { next = "index.html"; }

  var GROUPS = {
    student: { key: SS.KEYS.acctStudent, cfg: INST.student || {} },
    staff:   { key: SS.KEYS.acctStaff,   cfg: INST.staff   || {} }
  };
  function re(cfg) { try { return new RegExp(cfg.pattern); } catch (e) { return /^[A-Z0-9]{4,20}$/; } }
  /* Which group does this number belong to? Students first, then staff. */
  function roleOf(num) {
    if (re(GROUPS.student.cfg).test(num)) { return "student"; }
    if (re(GROUPS.staff.cfg).test(num)) { return "staff"; }
    return "";
  }
  function acct(role) { var x = SS.read(GROUPS[role].key, null); return x && x.salt && x.profile ? x : null; }

  function $(id) { return document.getElementById(id); }
  var els = {
    title: $("loginTitle"), form: $("loginForm"), id: $("studentNo"), idHint: $("studentHint"),
    pw: $("password"), pw2: $("password2"), confirmRow: $("confirmRow"), show: $("showPw"),
    err: $("loginError"), weak: $("weakNote"), btn: $("loginBtn"), note: $("createNote"),
    forgotBox: $("forgotBox"), forgot: $("forgotBtn")
  };
  document.querySelectorAll(".inst-name").forEach(function (n) { n.textContent = INST.name || "your institution"; });
  var sc = INST.student || {}, fc = INST.staff || {};
  els.idHint.textContent = "Students: " + (sc.hint || "your student number") + (sc.example ? " (for example " + sc.example + ")" : "") + ". Staff: " + (fc.hint || "your staff number") + ".";
  els.id.placeholder = sc.example || "";

  var creating = false, fails = 0;
  function showError(msg) { els.err.textContent = msg; els.err.hidden = false; }
  function clearError() { els.err.hidden = true; }

  /* As the number is typed: if it is valid and this device has no account for it yet, ask for the password twice */
  function setMode() {
    var role = roleOf(els.id.value.trim().toUpperCase());
    creating = !!role && !acct(role);
    els.confirmRow.hidden = els.note.hidden = !creating;
    els.title.textContent = creating ? "Create your account" : "Sign in";
    els.btn.textContent = creating ? "Create account and continue" : "Sign in";
    els.pw.setAttribute("autocomplete", creating ? "new-password" : "current-password");
  }
  els.id.addEventListener("input", function () { clearError(); setMode(); });
  [els.pw, els.pw2].forEach(function (i) { i.addEventListener("input", clearError); });
  els.show.addEventListener("change", function () {
    var t = els.show.checked ? "text" : "password"; els.pw.type = t; els.pw2.type = t;
  });
  setMode();

  if (!SS.secureCrypto) {
    els.btn.disabled = true;
    els.weak.textContent = "SpeakSafe needs a secure connection (https) to lock your journal. Please open the https address of this site.";
    els.weak.hidden = false;
  } else if (!SS.storageOk) {
    showError("Your browser is blocking storage (private browsing or a strict setting), so SpeakSafe cannot save your account. Try a normal window.");
  }

  function lockFor(seconds) {       // slow down guessing: 5 wrong tries = 30 second wait
    els.btn.disabled = true;
    var left = seconds;
    var t = setInterval(function () {
      left--; els.btn.textContent = "Try again in " + left + "s";
      if (left <= 0) { clearInterval(t); els.btn.disabled = false; setMode(); fails = 0; clearError(); }
    }, 1000);
    els.btn.textContent = "Try again in " + left + "s";
  }

  els.form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (els.btn.disabled) { return; }
    clearError();
    var num = els.id.value.trim().toUpperCase(), role = roleOf(num), pw = els.pw.value;
    if (!role) {
      showError("That does not look like a " + (INST.name || "") + " student or staff number. Students: " + (sc.hint || "") + (sc.example ? ", for example " + sc.example : "") + ".");
      els.id.focus(); return;
    }
    if (pw.length < 8) { showError("Your password must be at least 8 characters."); els.pw.focus(); return; }
    var stored = acct(role); creating = !stored;
    if (creating && pw !== els.pw2.value) { setMode(); showError("The two passwords do not match."); els.pw2.focus(); return; }
    els.btn.disabled = true;

    function finish(key, profile) { return V.saveSession(key, role, profile).then(function () { window.location.replace(next); }); }

    if (creating) {
      var salt = V.b64(V.randomBytes(16));
      var profile = { role: role, num: num, inst: INST.name || "" };
      V.deriveKey(num, pw, salt).then(function (key) {
        return V.encJSON(key, profile).then(function (box) {
          if (!SS.write(GROUPS[role].key, { v: 3, salt: salt, profile: box })) { throw new Error("storage"); }
          return finish(key, profile);
        });
      }).catch(function () { els.btn.disabled = false; showError("Could not save your account. Your browser may be blocking storage."); });
    } else {
      V.deriveKey(num, pw, stored.salt).then(function (key) {
        return V.decJSON(key, stored.profile).then(function (profile) { return finish(key, profile); }, function () {
          fails++; els.btn.disabled = false;
          showError("That number or password is not right.");
          if (fails >= 5) { lockFor(30); }
        });
      }).catch(function () { els.btn.disabled = false; showError("Something went wrong. Please try again."); });
    }
  });

  els.forgot.addEventListener("click", function () {
    if (window.confirm("This deletes your account, journal and photos from this browser. Continue?")) {
      SS.eraseAll(); window.location.replace("access.html");
    }
  });
})();
