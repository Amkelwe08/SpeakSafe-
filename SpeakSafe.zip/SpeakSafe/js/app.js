/* SpeakSafe — shared behaviour: storage helpers, encrypted vault, login gate, header, EXIT, bottom nav. */
(function () {
  "use strict";

  var CFG = window.SS_CONFIG || { decoyPage: "weather.html" };
  var KEYS = {
    acctStudent: "ss_acct_student", acctStaff: "ss_acct_staff",   // locked account (details are encrypted with the password)
    journal: "ss_journal_enc", reportLog: "ss_reportlog_enc",     // encrypted with the key made from the password
    unlocked: "ss_unlocked", role: "ss_role", key: "ss_key", profile: "ss_profile"   // this tab only; cleared on EXIT / sign out
  };
  var LEGACY_KEYS = ["ss_pin", "ss_login", "ss_login_lecturer", "ss_login_worker", "ss_journal", "ss_reports"];   // earlier versions
  var page = document.body.getAttribute("data-page") || "";

  /* ---------- storage helpers ---------- */
  function storageWorks() {
    try {
      localStorage.setItem("ss_test", "1");
      localStorage.removeItem("ss_test");
      return true;
    } catch (e) { return false; }
  }
  function read(key, fallback) {
    try {
      var v = localStorage.getItem(key);
      return v ? JSON.parse(v) : fallback;
    } catch (e) { return fallback; }
  }
  function write(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; }
    catch (e) { return false; }
  }
  var SESSION = [KEYS.unlocked, KEYS.role, KEYS.key, KEYS.profile];
  function clearSession() { try { SESSION.forEach(function (k) { sessionStorage.removeItem(k); }); } catch (e) {} }
  function eraseAll() {
    try {
      Object.keys(KEYS).forEach(function (k) { localStorage.removeItem(KEYS[k]); });
      LEGACY_KEYS.forEach(function (k) { localStorage.removeItem(k); });
    } catch (e) {}
    clearSession();
    try { if (window.indexedDB) { indexedDB.deleteDatabase("speaksafe"); } } catch (e) {}   // journal photos
  }

  /* ---------- the vault: everything personal is encrypted with a key made from number + password ----------
     AES-GCM 256. The key is made with PBKDF2 (200,000 rounds) and exists only in this tab while signed in.
     Needs a secure connection (https or localhost). Without one, SpeakSafe does not let anyone sign in. */
  var secureCrypto = !!(window.crypto && window.crypto.subtle && window.TextEncoder && window.isSecureContext !== false);
  var enc = window.TextEncoder ? new TextEncoder() : null, dec = window.TextDecoder ? new TextDecoder() : null;

  function b64(bytes) { var s = ""; bytes = new Uint8Array(bytes); for (var i = 0; i < bytes.length; i++) { s += String.fromCharCode(bytes[i]); } return btoa(s); }
  function unb64(str) { var s = atob(str), b = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) { b[i] = s.charCodeAt(i); } return b; }
  function randomBytes(n) { var b = new Uint8Array(n); window.crypto.getRandomValues(b); return b; }

  function deriveKey(number, password, saltB64) {
    return crypto.subtle.importKey("raw", enc.encode(number + ":" + password), "PBKDF2", false, ["deriveKey"]).then(function (m) {
      return crypto.subtle.deriveKey({ name: "PBKDF2", salt: unb64(saltB64), iterations: 200000, hash: "SHA-256" }, m,
        { name: "AES-GCM", length: 256 }, true, ["encrypt", "decrypt"]);
    });
  }
  function encBytes(key, bytes) {
    var iv = randomBytes(12);
    return crypto.subtle.encrypt({ name: "AES-GCM", iv: iv }, key, bytes).then(function (ct) { return { iv: b64(iv), ct: b64(ct) }; });
  }
  function decBytes(key, box) { return crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(box.iv) }, key, unb64(box.ct)); }
  function encJSON(key, obj) { return encBytes(key, enc.encode(JSON.stringify(obj))); }
  function decJSON(key, box) { return decBytes(key, box).then(function (buf) { return JSON.parse(dec.decode(buf)); }); }

  /* the key for the signed-in person (kept in this tab only) */
  function sessionKey() {
    var raw = null;
    try { raw = sessionStorage.getItem(KEYS.key); } catch (e) {}
    if (!raw || !secureCrypto) { return Promise.reject(new Error("locked")); }
    return crypto.subtle.importKey("raw", unb64(raw), { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
  }
  function saveSession(key, role, profile) {
    return crypto.subtle.exportKey("raw", key).then(function (raw) {
      sessionStorage.setItem(KEYS.key, b64(raw));
      sessionStorage.setItem(KEYS.role, role);
      sessionStorage.setItem(KEYS.profile, JSON.stringify(profile));
      sessionStorage.setItem(KEYS.unlocked, "1");
    });
  }
  function profile() {
    try { return JSON.parse(sessionStorage.getItem(KEYS.profile) || "null"); } catch (e) { return null; }
  }
  /* encrypted lists in localStorage (journal, report log) */
  function vaultLoad(storeKey) {
    var box = read(storeKey, null);
    if (!box) { return Promise.resolve([]); }
    return sessionKey().then(function (k) { return decJSON(k, box); }).then(function (l) { return Array.isArray(l) ? l : []; });
  }
  function vaultSave(storeKey, list) {
    return sessionKey().then(function (k) { return encJSON(k, list); }).then(function (box) {
      if (!write(storeKey, box)) { throw new Error("storage"); }
      return true;
    });
  }
  /* photos: encrypted bytes (12 byte iv first) inside a Blob */
  function encBlob(blob) {
    return Promise.all([sessionKey(), new Response(blob).arrayBuffer()]).then(function (r) {
      var iv = randomBytes(12);
      return crypto.subtle.encrypt({ name: "AES-GCM", iv: iv }, r[0], r[1]).then(function (ct) {
        return new Blob([iv, new Uint8Array(ct)], { type: "application/octet-stream" });
      });
    });
  }
  function decBlob(blob, type) {
    return Promise.all([sessionKey(), new Response(blob).arrayBuffer()]).then(function (r) {
      var all = new Uint8Array(r[1]);
      return crypto.subtle.decrypt({ name: "AES-GCM", iv: all.slice(0, 12) }, r[0], all.slice(12));
    }).then(function (pt) { return new Blob([pt], { type: type || "image/jpeg" }); });
  }

  /* ---------- EXIT (behaviour unchanged) ----------
     Blanks the page and replaces the current history entry with the decoy page.
     It does NOT delete browser history, saved entries, or other traces of using the site. */
  function exit() {
    clearSession();
    document.body.innerHTML = "";
    window.location.replace(CFG.decoyPage);
  }

  function signOut() {
    clearSession();
    window.location.replace("access.html");
  }

  /* ---------- login gate: every page except sign-in and the decoy ---------- */
  function currentFile() {
    var f = window.location.pathname.split("/").pop();
    return f || "index.html";
  }
  if (page !== "access" && page !== "decoy") {
    var unlocked = false;
    try { unlocked = sessionStorage.getItem(KEYS.unlocked) === "1" && !!sessionStorage.getItem(KEYS.key); } catch (e) {}
    if (!unlocked) {
      window.location.replace("access.html?next=" + encodeURIComponent(currentFile()));
      return;
    }
  }
  if (page === "decoy") { return; }

  /* ---------- icons ---------- */
  var ICONS = {
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
    rights: '<path d="M12 3v18"/><path d="M5 7h14"/><path d="M5 7l-3 7a3 3 0 006 0z"/><path d="M19 7l-3 7a3 3 0 006 0z"/>',
    journal: '<path d="M5 3h12a2 2 0 012 2v16H7a2 2 0 01-2-2z"/><path d="M9 8h6M9 12h6"/>',
    report: '<path d="M4 21V4"/><path d="M4 4h13l-2 4 2 4H4"/>',
    help: '<path d="M12 21s-7-4.5-7-11a4 4 0 017-2.5A4 4 0 0119 10c0 6.5-7 11-7 11z"/>'
  };
  function icon(name) {
    return '<svg viewBox="0 0 24 24" aria-hidden="true">' + ICONS[name] + "</svg>";
  }

  /* ---------- skip link, header, nav ---------- */
  var skip = document.createElement("a");
  skip.className = "skip-link";
  skip.href = "#main";
  skip.textContent = "Skip to main content";
  document.body.insertBefore(skip, document.body.firstChild);

  var header = document.createElement("header");
  header.className = "topbar";
  header.innerHTML =
    '<a class="brand" href="index.html">SpeakSafe<small>for women</small></a>' +
    '<button type="button" class="exit-btn" id="exitBtn" aria-label="Exit this site now">EXIT</button>';
  document.body.insertBefore(header, skip.nextSibling);

  if (page !== "access") {
    var items = [
      ["home", "Home", "index.html"],
      ["rights", "Rights", "rights.html"],
      ["journal", "Journal", "journal.html"],
      ["report", "Report", "report.html"],
      ["help", "Help", "support.html"]
    ];
    var nav = document.createElement("nav");
    nav.className = "bottom-nav";
    nav.setAttribute("aria-label", "Main");
    nav.innerHTML = items.map(function (it) {
      var cur = (page === it[0]) ? ' aria-current="page"' : "";
      return '<a href="' + it[2] + '"' + cur + ">" + icon(it[0]) + "<span>" + it[1] + "</span></a>";
    }).join("");
    document.body.appendChild(nav);
  }

  document.getElementById("exitBtn").addEventListener("click", exit);
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") { exit(); } });
  document.querySelectorAll("[data-signout]").forEach(function (b) { b.addEventListener("click", signOut); });

  /* ---------- toast ---------- */
  function toast(message) {
    var t = document.getElementById("toast");
    if (!t) {
      t = document.createElement("div");
      t.id = "toast"; t.className = "toast"; t.setAttribute("role", "status");
      document.body.appendChild(t);
    }
    t.textContent = message; t.hidden = false;
    clearTimeout(t._timer);
    t._timer = setTimeout(function () { t.hidden = true; }, 2600);
  }

  /* ---------- download helper ---------- */
  function download(filename, text) {
    var blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  window.SS = {
    KEYS: KEYS, read: read, write: write, eraseAll: eraseAll,
    vault: { deriveKey: deriveKey, encJSON: encJSON, decJSON: decJSON, saveSession: saveSession, profile: profile,
             load: vaultLoad, save: vaultSave, encBlob: encBlob, decBlob: decBlob, b64: b64, unb64: unb64, randomBytes: randomBytes },
    exit: exit, signOut: signOut, toast: toast, download: download, config: CFG,
    storageOk: storageWorks(), secureCrypto: secureCrypto
  };
})();
