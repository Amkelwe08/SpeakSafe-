/* SpeakSafe settings. To set SpeakSafe up for another institution, change this file only. */
window.SS_CONFIG = {
  // Where the EXIT button sends people (a page in the same html folder, or a full web address).
  decoyPage: "weather.html",

  /* ---------- The institution ---------- */
  institution: {
    name: "Rosebank College",
    serialPrefix: "RB",                       // serial codes look like RB-7K3M-9QX2

    // Who may create an account, and what their number looks like. pattern is a regular expression
    // tested against the number after it is trimmed and put in capitals.
    // Rosebank students: "ST" followed by digits (for example ST10490509).
    student: { label: "Student number", pattern: "^ST\\d{4,10}$",       example: "ST10490509", hint: "Starts with ST, then your numbers" },
    // Staff number format: change this to match the institution's real format.
    staff:   { label: "Staff number",   pattern: "^[A-Z0-9]{4,15}$",     example: "LEC12345",   hint: "Letters and numbers only" }
  },

  /* ---------- Who receives reports ---------- */
  // Students and staff both report to Student Wellness (point "staff" at another entry to change that).
  roles: {
    student: { label: "Student", to: "wellness" },
    staff:   { label: "Staff",   to: "wellness" }
  },
  recipients: {
    // TEMPORARY: reports go to this address until Student Wellness' own address is known.
    // When you have it, change this one line. (FormSubmit asks the new address to confirm once, see README.)
    wellness: { label: "Student Wellness", salutation: "Dear Student Wellness team,", email: "maqinasesokabo@gmail.com" }
  },

  /* ---------- Sending ---------- */
  // auto: true  -> "Send my report" posts the report straight to the receiver's email (no copying, no typing),
  //                using the free FormSubmit forwarding service (formsubmit.co).
  // endpoint    -> optional: your own server address. If set, it is used instead of FormSubmit. See README.
  // If automatic sending fails, the person can still download the PDF or open an email.
  delivery: { auto: true, endpoint: "" },

  /* ---------- Identity sealing ---------- */
  // Every report carries a SEALED identity code that only Student Wellness can open, using their PRIVATE key.
  // This is the PUBLIC half (safe to publish). The key below is a DEMO key: its private half is in
  // tools/demo-wellness-private-key.pem. Before real use, Student Wellness makes their own key pair on
  // html/wellness.html, keeps the private key safe, and pastes the new public key here.
  wellnessPublicKey: "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0LXbaZ/0nlyBKe46oje7tIQLUQA+q1hBAW8iOWBmeQZ0BTjEcL5MvaRjGhrOysWCmJ/vIcJJRj22U7JcUMw/RTQp/tTyFJIyWTxKVwmKvX7X49A1fSV3MELu9/j0a56nifxssc4YhAHQ2SfYSPl2H2sVtlcL97bmmGQGYmRKcuwu9rgfvoKhfRRKZ2dGH6LhwR8vOvtREV8qrAnxZExyKswyayG7C5qfEaF7vAOA4O31VZwmnHMSOelS8tH9d64VpwinYwJ4PQQLeM2odFgBWpTr/YKtOtE16ovPmgZlMMOtkzNN7LufR32bxXH0UE3mIVRx5IiBj0HnkYZbK5euWQIDAQAB"
};
