(function () {
  "use strict";
  if (!window.SS) { return; }

  var stage = document.getElementById("stage");

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) { n.className = cls; }
    if (text) { n.textContent = text; }
    return n;
  }
  function link(href, label, cls) {
    var a = el("a", cls, label); a.href = href; return a;
  }
  function button(label, cls, onClick) {
    var b = el("button", cls, label); b.type = "button"; b.addEventListener("click", onClick); return b;
  }
  function show(node) {
    stage.innerHTML = "";
    stage.appendChild(node);
    node.scrollIntoView({ behavior: "smooth", block: "start" });
    var h = node.querySelector("h2"); if (h) { h.setAttribute("tabindex", "-1"); h.focus({ preventScroll: true }); }
  }

  /* Step 1: safety */
  function stepSafety() {
    var box = el("section", "panel");
    box.appendChild(el("h2", "", "Are you safe right now?"));
    var row = el("div", "btn-row");
    row.appendChild(button("No, I am in danger", "btn btn-danger", stepDanger));
    row.appendChild(button("Yes, I am safe for now", "btn btn-primary", stepWhen));
    box.appendChild(row);
    show(box);
  }

  function stepDanger() {
    var box = el("section", "panel alert");
    box.appendChild(el("h2", "", "Get to safety first"));
    box.appendChild(el("p", "", "If you can, move to a place with other people, or lock yourself in a safe room. Then call one of these."));
    var list = el("ul", "contacts");
    [["Police", "10111", "tel:10111", "Emergency, any phone"],
     ["Emergency from a cell phone", "112", "tel:112", "From a cell phone"],
     ["GBV Command Centre", "0800 428 428", "tel:0800428428", "24 hours, free, counsellors"]
    ].forEach(function (c) {
      var li = el("li");
      var info = el("div");
      info.appendChild(el("b", "", c[0])); info.appendChild(el("span", "", c[3]));
      li.appendChild(info);
      li.appendChild(link(c[2], "Call " + c[1], "call urgent"));
      list.appendChild(li);
    });
    box.appendChild(list);
    box.appendChild(button("I am safe now, continue", "btn", stepWhen));
    show(box);
  }

  /* Step 2: timing */
  function stepWhen() {
    var box = el("section", "panel");
    box.appendChild(el("h2", "", "When did it happen?"));
    var row = el("div", "btn-row");
    [["In the last 72 hours", "recent"],
     ["Longer ago", "older"],
     ["It keeps happening", "ongoing"],
     ["I am not sure", "unsure"]
    ].forEach(function (o) {
      row.appendChild(button(o[0], "btn", function () { stepOptions(o[1]); }));
    });
    box.appendChild(row);
    show(box);
  }

  var ADVICE = {
    recent: {
      title: "Within the last 72 hours",
      steps: [
        "Get medical care as soon as you can, ideally within 72 hours. A clinic or hospital can give you medication to lower the risk of HIV (called PEP), emergency contraception, and treatment for injuries.",
        "Many hospitals have a Thuthuzela Care Centre, where medical care, counselling and police support are in one place. The GBV Command Centre can tell you the nearest one.",
        "If you can, avoid washing, changing clothes or cleaning up before you are examined. If you already did, you can still get care and still report.",
        "Write down what you remember in the journal, even if it is in pieces.",
        "You decide if and when to report to the police. Care comes first."
      ]
    },
    older: {
      title: "It happened some time ago",
      steps: [
        "It is not too late. You can still report, get counselling and get advice.",
        "Write down what you remember: dates, places, people, what was said. Small details help later.",
        "Keep messages, photos, emails and anything else that relates to it. Take screenshots and store them somewhere safe.",
        "Think about someone you trust who can know. You do not have to carry this alone.",
        "A counsellor or legal adviser can explain your options without you having to commit to anything."
      ]
    },
    ongoing: {
      title: "It keeps happening",
      steps: [
        "Keep a record each time: date, time, place, what happened, and who saw it. The journal is built for this.",
        "Save messages, voice notes and emails. Screenshots help.",
        "You can apply for a protection order at the magistrate's court. It is free and you do not need a lawyer. Different laws cover relationships and harassment (see Your rights).",
        "Plan ahead: a safe place you can go, a trusted person to call, and copies of important documents kept somewhere else.",
        "If it is connected to your studies or job, your institution or employer has a duty to act once they know."
      ]
    },
    unsure: {
      title: "You are not sure",
      steps: [
        "You do not need the right word for it to deserve support. If something felt wrong, scary or unfair, it matters.",
        "Writing it down can help you see it more clearly. You can keep it private.",
        "Talking to a trained counsellor does not commit you to anything, and it is free. The GBV Command Centre is open all day and night.",
        "Read the rights page to see what is and is not acceptable at university or work."
      ]
    }
  };

  function stepOptions(key) {
    var info = ADVICE[key];
    var box = el("section");
    var panel = el("div", "panel");
    panel.appendChild(el("h2", "", info.title));
    var ul = el("ul");
    ul.style.paddingLeft = "1.2em";
    info.steps.forEach(function (s) { var li = el("li", "", s); li.style.marginBottom = ".6em"; ul.appendChild(li); });
    panel.appendChild(ul);
    box.appendChild(panel);

    var next = el("div", "btn-row");
    next.appendChild(link("journal.html", "Write in my journal", "btn btn-primary"));
    next.appendChild(link("report.html", "Make a report", "btn"));
    next.appendChild(link("rights.html", "Know my rights", "btn"));
    next.appendChild(link("support.html", "Talk to someone", "btn"));
    box.appendChild(next);

    var back = el("div", "btn-row");
    back.appendChild(button("Go back", "btn btn-quiet", stepWhen));
    box.appendChild(back);
    show(box);
  }

  stepSafety();
})();
