/* SpeakSafe — optional photos/screenshots for the REPORT and JOURNAL pages only.
   - Paste an image into the text box (Ctrl+V) or choose files with the button.
   - Every image is re-drawn onto a canvas and saved as a smaller JPEG. This also removes hidden
     photo details such as GPS location and camera info (EXIF).
   - Journal images are kept in this browser's IndexedDB. They are NOT encrypted.
   - Report images are never stored; they only go into the PDF the reporter downloads. */
(function () {
  "use strict";

  var MAX_SIDE = 1280, QUALITY = 0.78, MAX_INPUT_BYTES = 20 * 1024 * 1024;

  function decode(file) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () { URL.revokeObjectURL(url); resolve(img); };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error("decode")); };
      img.src = url;
    });
  }

  /* file -> Promise<Blob (jpeg, max 1280px)> */
  function compress(file) {
    if (!file || !/^image\//.test(file.type || "")) { return Promise.reject(new Error("type")); }
    if (file.size > MAX_INPUT_BYTES) { return Promise.reject(new Error("size")); }
    return decode(file).then(function (img) {
      var w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
      if (!w || !h) { throw new Error("decode"); }
      var scale = Math.min(1, MAX_SIDE / Math.max(w, h));
      var cw = Math.max(1, Math.round(w * scale)), ch = Math.max(1, Math.round(h * scale));
      var canvas = document.createElement("canvas");
      canvas.width = cw; canvas.height = ch;
      var ctx = canvas.getContext("2d");
      ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, cw, ch);   // transparent PNGs become white
      ctx.drawImage(img, 0, 0, cw, ch);
      return new Promise(function (resolve, reject) {
        canvas.toBlob(function (b) { b ? resolve(b) : reject(new Error("encode")); }, "image/jpeg", QUALITY);
      });
    });
  }

  function blobToDataURL(blob) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(r.result); };
      r.onerror = function () { reject(new Error("read")); };
      r.readAsDataURL(blob);
    });
  }

  var MESSAGES = {
    type: "That file is not an image. Choose a photo or screenshot.",
    size: "That image is too large (over 20 MB). Choose a smaller one.",
    decode: "That image could not be read. Try a screenshot, JPEG or PNG.",
    encode: "That image could not be processed. Try a different one."
  };

  /* Wires up paste + file picker + thumbnails.
     opts: { textarea, fileInput, list, errorEl, max } -> controller */
  function attach(opts) {
    var items = [];          // { blob, url }
    var pending = 0;

    function showErr(msg) { opts.errorEl.textContent = msg; opts.errorEl.hidden = !msg; }

    function render() {
      opts.list.innerHTML = "";
      items.forEach(function (it, i) {
        var li = document.createElement("li");
        var img = document.createElement("img");
        img.src = it.url; img.alt = "Attached image " + (i + 1) + " of " + items.length;
        var btn = document.createElement("button");
        btn.type = "button"; btn.textContent = "Remove";
        btn.setAttribute("aria-label", "Remove image " + (i + 1));
        btn.addEventListener("click", function () {
          URL.revokeObjectURL(it.url);
          items.splice(items.indexOf(it), 1);
          showErr(""); render();
          opts.fileInput.focus();
        });
        li.appendChild(img); li.appendChild(btn);
        opts.list.appendChild(li);
      });
    }

    function addFiles(fileList) {
      var files = Array.prototype.slice.call(fileList || []);
      if (!files.length) { return Promise.resolve(); }
      showErr("");
      var room = opts.max - items.length - pending;
      if (room <= 0) { showErr("You can attach up to " + opts.max + " images. Remove one to add another."); return Promise.resolve(); }
      var tooMany = files.length > room;
      files = files.slice(0, room);
      pending += files.length;
      var firstError = "";
      var chain = files.reduce(function (p, f) {
        return p.then(function () {
          return compress(f).then(function (blob) {
            items.push({ blob: blob, url: URL.createObjectURL(blob) });
          }, function (err) {
            if (!firstError) { firstError = MESSAGES[err && err.message] || MESSAGES.decode; }
          }).then(function () { pending--; });
        });
      }, Promise.resolve());
      return chain.then(function () {
        render();
        if (firstError) { showErr(firstError); }
        else if (tooMany) { showErr("Only the first " + room + " image(s) were added. The limit is " + opts.max + "."); }
      });
    }

    opts.fileInput.addEventListener("change", function () {
      addFiles(opts.fileInput.files).then(function () { opts.fileInput.value = ""; });
    });

    opts.textarea.addEventListener("paste", function (e) {
      var cd = e.clipboardData;
      if (!cd || !cd.items) { return; }
      var files = [];
      for (var i = 0; i < cd.items.length; i++) {
        var it = cd.items[i];
        if (it.kind === "file" && /^image\//.test(it.type)) { var f = it.getAsFile(); if (f) { files.push(f); } }
      }
      if (!files.length) { return; }
      if (!cd.getData("text/plain")) { e.preventDefault(); }   // image only: do not insert anything into the text
      addFiles(files);
    });

    return {
      blobs: function () { return items.map(function (it) { return it.blob; }); },
      count: function () { return items.length; },
      busy: function () { return pending > 0; },
      clear: function () { items.forEach(function (it) { URL.revokeObjectURL(it.url); }); items = []; showErr(""); render(); }
    };
  }

  /* ---------- IndexedDB store for journal images ---------- */
  var DB_NAME = "speaksafe", STORE = "images";
  function openDb() {
    return new Promise(function (resolve, reject) {
      if (!window.indexedDB) { reject(new Error("no-idb")); return; }
      var req;
      try { req = indexedDB.open(DB_NAME, 1); } catch (e) { reject(e); return; }
      req.onupgradeneeded = function () { req.result.createObjectStore(STORE, { keyPath: "id" }); };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { reject(req.error || new Error("idb")); };
      req.onblocked = function () { reject(new Error("idb-blocked")); };
    });
  }
  function tx(mode, fn) {
    return openDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var t = db.transaction(STORE, mode), store = t.objectStore(STORE), out = fn(store);
        t.oncomplete = function () { db.close(); resolve(out && out.result !== undefined ? out.result : undefined); };
        t.onerror = t.onabort = function () { db.close(); reject(t.error || new Error("idb")); };
      });
    });
  }
  var store = {
    put: function (id, blob) { return tx("readwrite", function (s) { return s.put({ id: id, blob: blob }); }); },
    get: function (id) { return tx("readonly", function (s) { return s.get(id); }).then(function (rec) { return rec ? rec.blob : null; }); },
    del: function (ids) { return tx("readwrite", function (s) { ids.forEach(function (id) { s.delete(id); }); }); },
    clear: function () { return tx("readwrite", function (s) { return s.clear(); }); }
  };

  window.SSImages = { attach: attach, compress: compress, blobToDataURL: blobToDataURL, store: store };
})();
