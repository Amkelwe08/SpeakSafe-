(function () {
  "use strict";
  if (!window.SS) { return; }
  var SS = window.SS;
  var Img = window.SSImages;

  var form = document.getElementById("journalForm");
  var listEl = document.getElementById("entries");
  var dateEl = document.getElementById("jDate");
  var moodEl = document.getElementById("jMood");
  var textEl = document.getElementById("jText");
  var errEl = document.getElementById("jError");

  var attach = Img ? Img.attach({
    textarea: textEl,
    fileInput: document.getElementById("jFile"),
    list: document.getElementById("jThumbs"),
    errorEl: document.getElementById("jImgErr"),
    max: 5
  }) : null;

  var objectUrls = [];   // thumbnails shown in saved entries, released on re-render

  function today() {
    var d = new Date();
    var m = ("0" + (d.getMonth() + 1)).slice(-2), day = ("0" + d.getDate()).slice(-2);
    return d.getFullYear() + "-" + m + "-" + day;
  }
  dateEl.value = today();
  dateEl.max = today();

  /* The journal is encrypted with the key made from your number + password, so it cannot be read without
     signing in. Photos are encrypted too. Both stay on this device. */
  var V = SS.vault;
  function load() { return V.load(SS.KEYS.journal); }                       // -> Promise<list>
  function save(list) { return V.save(SS.KEYS.journal, list); }             // -> Promise<true>
  function putImage(id, blob) { return V.encBlob(blob).then(function (enc) { return Img.store.put(id, enc); }); }
  function getImage(id) {
    return Img.store.get(id).then(function (enc) { return enc ? V.decBlob(enc, "image/jpeg") : null; });
  }

  function prettyDate(iso) {
    var p = iso.split("-");
    if (p.length !== 3) { return iso; }
    return new Date(+p[0], +p[1] - 1, +p[2]).toLocaleDateString("en-ZA", { day: "numeric", month: "long", year: "numeric" });
  }

  function newId() { return String(Date.now()) + Math.random().toString(36).slice(2, 7); }

  function renderImages(entry, box) {
    if (!entry.images || !entry.images.length || !Img) { return; }
    var ul = document.createElement("ul");
    ul.className = "thumbs";
    box.appendChild(ul);
    entry.images.forEach(function (id, i) {
      getImage(id).then(function (blob) {
        var li = document.createElement("li");
        if (!blob) {
          li.textContent = "Photo " + (i + 1) + " is no longer available on this device.";
          ul.appendChild(li); return;
        }
        var url = URL.createObjectURL(blob);
        objectUrls.push(url);
        var img = document.createElement("img");
        img.src = url; img.alt = "Photo " + (i + 1) + " of " + entry.images.length + " saved with this entry. Select to enlarge.";
        img.tabIndex = 0;
        function toggle() { li.classList.toggle("big"); }
        img.addEventListener("click", toggle);
        img.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggle(); } });
        li.appendChild(img); ul.appendChild(li);
      }, function () {
        var li = document.createElement("li");
        li.textContent = "Photo " + (i + 1) + " could not be loaded.";
        ul.appendChild(li);
      });
    });
  }

  function render() {
    return load().then(draw, function () {
      listEl.innerHTML = "";
      var bad = document.createElement("div"); bad.className = "empty";
      bad.textContent = "Your journal could not be unlocked. Please sign out and sign in again.";
      listEl.appendChild(bad);
    });
  }

  function draw(all) {
    objectUrls.forEach(function (u) { URL.revokeObjectURL(u); });
    objectUrls = [];
    var list = all.slice().sort(function (a, b) {
      return (b.date + b.created).localeCompare(a.date + a.created);
    });
    listEl.innerHTML = "";
    if (!list.length) {
      var empty = document.createElement("div");
      empty.className = "empty";
      empty.textContent = "Nothing saved yet. When you are ready, write your first entry above.";
      listEl.appendChild(empty);
      return;
    }
    list.forEach(function (entry) {
      var box = document.createElement("article");
      box.className = "entry";

      var head = document.createElement("div");
      var time = document.createElement("time");
      time.setAttribute("datetime", entry.date);
      time.textContent = prettyDate(entry.date);
      head.appendChild(time);
      if (entry.mood) {
        var mood = document.createElement("span");
        mood.className = "mood";
        mood.textContent = "Feeling " + entry.mood.toLowerCase();
        head.appendChild(mood);
      }
      box.appendChild(head);

      if (entry.text) {
        var body = document.createElement("p");
        body.textContent = entry.text;           // textContent keeps user text safe
        box.appendChild(body);
      }
      renderImages(entry, box);

      var del = document.createElement("button");
      del.type = "button";
      del.textContent = "Delete this entry";
      del.addEventListener("click", function () {
        if (!window.confirm("Delete this entry" + (entry.images && entry.images.length ? " and its photos" : "") + "? This cannot be undone.")) { return; }
        load().then(function (l) { return save(l.filter(function (e) { return e.id !== entry.id; })); }).then(function () {
          if (entry.images && entry.images.length && Img) { Img.store.del(entry.images).catch(function () {}); }
          render();
          SS.toast("Entry deleted");
        }, function () { SS.toast("Could not delete. Your browser may be blocking storage."); });
      });
      box.appendChild(del);
      listEl.appendChild(box);
    });
  }

  function fail(msg, focusEl) { errEl.textContent = msg; errEl.hidden = false; if (focusEl) { focusEl.focus(); } }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var text = textEl.value.trim();
    var nImg = attach ? attach.count() : 0;
    if (attach && attach.busy()) { fail("Please wait a moment while your photos finish loading.", null); return; }
    if (!text && !nImg) { fail("Write something or add a photo first, then save.", textEl); return; }
    if (dateEl.value && dateEl.value > today()) { fail("The date cannot be in the future.", dateEl); return; }
    errEl.hidden = true;

    var ids = [];
    var blobs = nImg ? attach.blobs() : [];
    var writeImages = Promise.resolve();
    if (blobs.length) {
      if (!Img) { fail("Photos are not available on this page.", null); return; }
      ids = blobs.map(newId);
      writeImages = Promise.all(blobs.map(function (b, i) { return putImage(ids[i], b); }));
    }

    var submitBtn = form.querySelector("button[type=submit]");
    submitBtn.disabled = true;
    writeImages.then(function () { return load(); }).then(function (list) {
      list.push({
        id: newId(),
        date: dateEl.value || today(),
        mood: moodEl.value,
        text: text,
        images: ids,
        created: new Date().toISOString()
      });
      return save(list);
    }).then(function () {
      textEl.value = ""; moodEl.value = "";
      if (attach) { attach.clear(); }
      render();
      SS.toast("Saved on this device");
    }).catch(function () {
      if (ids.length && Img) { Img.store.del(ids).catch(function () {}); }   // do not leave orphan photos
      SS.toast(blobs.length
        ? "Could not save the photos. Your browser may be blocking storage (private browsing?)."
        : "Could not save. Your browser may be blocking storage (private browsing?).");
    }).then(function () { submitBtn.disabled = false; });
  });

  document.getElementById("exportBtn").addEventListener("click", function () {
    load().then(function (list) {
    if (!list.length) { SS.toast("Nothing to download yet"); return; }
    var lines = ["SpeakSafe journal", "Downloaded " + new Date().toLocaleString("en-ZA"), ""];
    list.slice().sort(function (a, b) { return a.date.localeCompare(b.date); }).forEach(function (en) {
      lines.push(prettyDate(en.date) + (en.mood ? "  (" + en.mood + ")" : ""));
      if (en.text) { lines.push(en.text); }
      if (en.images && en.images.length) { lines.push("[" + en.images.length + " photo(s) saved with this entry, not included in this file]"); }
      lines.push("");
    });
    SS.download("speaksafe-journal.txt", lines.join("\n"));
    }, function () { SS.toast("Could not unlock your journal."); });
  });

  document.getElementById("eraseBtn").addEventListener("click", function () {
    load().then(function (l) {
      if (l.length && window.confirm("Erase ALL journal entries and photos on this device? This cannot be undone.")) {
        return save([]).then(function () {
          if (Img) { Img.store.clear().catch(function () {}); }
          render(); SS.toast("All entries erased");
        });
      }
    }).catch(function () { SS.toast("Could not erase. Your browser may be blocking storage."); });
  });

  render();
})();
