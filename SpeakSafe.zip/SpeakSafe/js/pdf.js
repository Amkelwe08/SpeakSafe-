/* SpeakSafe - tiny PDF writer for the REPORT page.
   - Runs entirely in the browser. No library, no network request, nothing is uploaded.
   - Plain text (Helvetica) plus optional JPEG photos (the report page already re-saves photos as JPEG).
   - The file contains NO author, creation date, producer or other hidden metadata.
   Usage: SSPdf.build(doc, images) -> Blob
     doc    = { title, subtitle, intro, rows: [[label, value], ...], footer, closing }
     images = [{ bytes: Uint8Array (JPEG), width, height }] */
(function () {
  "use strict";

  var PAGE_W = 595, PAGE_H = 842, MARGIN = 50, BOTTOM = 62, TOP_FIRST = 120, TOP_NEXT = 60;
  var BODY = 11, LEAD = 15.5;

  /* Helvetica widths (per 1000 em) for ASCII 32..126 */
  var W = [278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,
           556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,
           1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,
           667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,
           333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,
           556,556,333,500,278,556,500,722,500,500,500,334,260,334,584];

  var WIN = { 0x20AC: 0x80, 0x2026: 0x85, 0x2018: 0x91, 0x2019: 0x92, 0x201C: 0x93, 0x201D: 0x94, 0x2022: 0x95, 0x2013: 0x96, 0x2014: 0x97 };

  /* Unicode text -> string of WinAnsi characters (unknown characters become "?") */
  function clean(s) {
    s = String(s == null ? "" : s).replace(/\r\n?/g, "\n");
    var out = "";
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c === 10) { out += "\n"; }
      else if (c === 9) { out += "    "; }
      else if (c < 32 || c === 127) { out += " "; }
      else if (c < 127) { out += s.charAt(i); }
      else if (WIN[c]) { out += String.fromCharCode(WIN[c]); }
      else if (c >= 160 && c <= 255) { out += s.charAt(i); }
      else if (c >= 0xD800 && c <= 0xDFFF) { if (c < 0xDC00) { out += "?"; } }   // one "?" per emoji
      else if (c === 0x200B || c === 0xFE0F || c === 0x200D) { /* invisible: drop */ }
      else { out += "?"; }
    }
    return out;
  }

  function esc(s) { return s.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)"); }

  function width(s, size, bold) {
    var w = 0;
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      w += (c >= 32 && c <= 126) ? W[c - 32] : 600;
    }
    return w * size / 1000 * (bold ? 1.07 : 1);
  }

  /* Wrap one paragraph to a width. Very long words are split. */
  function wrap(par, maxW, size, bold) {
    if (par === "") { return [""]; }
    var words = par.split(" "), lines = [], line = "";
    words.forEach(function (word) {
      while (width(word, size, bold) > maxW) {           // a single word wider than the line
        var cut = word.length;
        while (cut > 1 && width(word.slice(0, cut), size, bold) > maxW) { cut--; }
        if (line) { lines.push(line); line = ""; }
        lines.push(word.slice(0, cut));
        word = word.slice(cut);
      }
      var test = line ? line + " " + word : word;
      if (line && width(test, size, bold) > maxW) { lines.push(line); line = word; }
      else { line = test; }
    });
    lines.push(line);
    return lines;
  }

  function bytesOf(str) {
    var b = new Uint8Array(str.length);
    for (var i = 0; i < str.length; i++) { b[i] = str.charCodeAt(i) & 255; }
    return b;
  }
  function pad10(n) { return ("0000000000" + n).slice(-10); }
  function num(n) { return (Math.round(n * 100) / 100).toString(); }

  function build(doc, images) {
    images = images || [];
    var pages = [], cur = null, y = 0;

    function newPage(first) {
      cur = []; pages.push(cur);
      y = PAGE_H - (first ? TOP_FIRST : TOP_NEXT);
      if (!first) {
        cur.push("BT /F1 9 Tf 0.48 0.35 0.47 rg " + MARGIN + " " + (PAGE_H - 36) + " Td (" + esc(clean("SpeakSafe report " + (doc.code || ""))) + ") Tj ET");
      }
    }
    function put(str, x, yy, size, bold, rgb) {
      cur.push("BT /" + (bold ? "F2" : "F1") + " " + size + " Tf " + rgb + " rg " + num(x) + " " + num(yy) + " Td (" + esc(str) + ") Tj ET");
    }
    function ensure(h) { if (y - h < BOTTOM) { newPage(false); } }

    function paragraph(text, size, bold, rgb, lead, gapAfter) {
      var maxW = PAGE_W - 2 * MARGIN;
      clean(text).split("\n").forEach(function (par) {
        wrap(par, maxW, size, bold).forEach(function (ln) {
          ensure(lead);
          y -= lead;
          if (ln) { put(ln, MARGIN, y, size, bold, rgb); }
        });
      });
      y -= (gapAfter || 0);
    }

    /* ---- first page: coloured header band ---- */
    newPage(true);
    cur.push("0.78 0.12 0.48 rg 0 " + (PAGE_H - 92) + " " + PAGE_W + " 92 re f");
    cur.push("0.56 0.27 0.84 rg 0 " + (PAGE_H - 96) + " " + PAGE_W + " 4 re f");
    put(clean(doc.title || "SpeakSafe report"), MARGIN, PAGE_H - 50, 22, true, "1 1 1");
    put(clean(doc.subtitle || ""), MARGIN, PAGE_H - 72, 11, false, "1 0.9 0.96");

    if (doc.intro) { paragraph(doc.intro, BODY, false, "0.29 0.06 0.26", LEAD, 12); }

    /* ---- rows ---- */
    (doc.rows || []).forEach(function (row) {
      ensure(LEAD * 2);
      y -= 8;
      put(clean(String(row[0]).toUpperCase()), MARGIN, y - 9, 8.5, true, "0.62 0.2 0.45");
      y -= 11;
      if (row[2] === "small") { paragraph(row[1], 7.5, false, "0.45 0.33 0.44", 10, 4); }   // long sealed code
      else { paragraph(row[1] || "Not given", BODY, false, "0.18 0.04 0.16", LEAD, 4); }
    });

    if (doc.closing) { y -= 6; paragraph(doc.closing, 10, false, "0.45 0.33 0.44", 14, 6); }

    /* ---- photos ---- */
    if (images.length) {
      var f0 = images[0], s0 = Math.min((PAGE_W - 2 * MARGIN) / f0.width, 520 / f0.height, 1.0);
      ensure(14 + 14 + f0.height * s0 + 18);        // keep the heading together with the first photo
      y -= 14;
      put("PHOTOS OR SCREENSHOTS ATTACHED BY THE REPORTER", MARGIN, y - 9, 8.5, true, "0.62 0.2 0.45");
      y -= 14;
      images.forEach(function (im, i) {
        var maxW = PAGE_W - 2 * MARGIN, maxH = 520;
        var s = Math.min(maxW / im.width, maxH / im.height, 1.0);
        var w = im.width * s, h = im.height * s;
        if (y - h - 18 < BOTTOM) { newPage(false); }
        y -= h;
        cur.push("q " + num(w) + " 0 0 " + num(h) + " " + MARGIN + " " + num(y) + " cm /Im" + (i + 1) + " Do Q");
        y -= 18;
      });
    }

    /* ---- footers (need total page count) ---- */
    var total = pages.length, footer = clean(doc.footer || "");
    pages.forEach(function (p, i) {
      cur = p;
      cur.push("0.9 0.7 0.82 rg " + MARGIN + " 46 " + (PAGE_W - 2 * MARGIN) + " 0.8 re f");
      put(footer, MARGIN, 32, 8, false, "0.48 0.35 0.47");
      var label = "Page " + (i + 1) + " of " + total;
      put(label, PAGE_W - MARGIN - width(label, 8, false), 32, 8, false, "0.48 0.35 0.47");
    });

    /* ---- assemble the file ---- */
    var nImg = images.length;
    var firstImg = 5, firstPage = 5 + nImg;
    var chunks = [], offsets = [], pos = 0;
    function write(b) { chunks.push(b); pos += b.length; }
    function obj(n, parts) {
      offsets[n] = pos;
      write(bytesOf(n + " 0 obj\n"));
      parts.forEach(function (p) { write(typeof p === "string" ? bytesOf(p) : p); });
      write(bytesOf("\nendobj\n"));
    }

    write(bytesOf("%PDF-1.4\n%\xE2\xE3\xCF\xD3\n"));

    var kids = [];
    for (var i = 0; i < total; i++) { kids.push((firstPage + 2 * i + 1) + " 0 R"); }
    obj(1, ["<< /Type /Catalog /Pages 2 0 R >>"]);
    obj(2, ["<< /Type /Pages /Kids [" + kids.join(" ") + "] /Count " + total + " >>"]);
    obj(3, ["<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"]);
    obj(4, ["<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>"]);

    images.forEach(function (im, k) {
      obj(firstImg + k, [
        "<< /Type /XObject /Subtype /Image /Width " + im.width + " /Height " + im.height +
        " /ColorSpace /" + (im.gray ? "DeviceGray" : "DeviceRGB") + " /BitsPerComponent 8 /Filter /DCTDecode /Length " + im.bytes.length + " >>\nstream\n",
        im.bytes, "\nendstream"
      ]);
    });

    var xo = "";
    images.forEach(function (im, k) { xo += "/Im" + (k + 1) + " " + (firstImg + k) + " 0 R "; });
    var resources = "<< /Font << /F1 3 0 R /F2 4 0 R >>" + (nImg ? " /XObject << " + xo + ">>" : "") + " >>";

    pages.forEach(function (p, i) {
      var content = bytesOf(p.join("\n"));
      obj(firstPage + 2 * i, ["<< /Length " + content.length + " >>\nstream\n", content, "\nendstream"]);
      obj(firstPage + 2 * i + 1, ["<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + PAGE_W + " " + PAGE_H + "] /Resources " + resources + " /Contents " + (firstPage + 2 * i) + " 0 R >>"]);
    });

    var count = firstPage + 2 * total;       // objects 1..count-1, plus the free entry 0
    var xrefPos = pos, x = "xref\n0 " + count + "\n0000000000 65535 f \n";
    for (var n = 1; n < count; n++) { x += pad10(offsets[n]) + " 00000 n \n"; }
    x += "trailer\n<< /Size " + count + " /Root 1 0 R >>\nstartxref\n" + xrefPos + "\n%%EOF\n";
    write(bytesOf(x));

    return new Blob(chunks, { type: "application/pdf" });
  }

  /* Read width/height/colour from a JPEG's header. Returns null if it is not a readable JPEG. */
  function jpegInfo(bytes) {
    if (!bytes || bytes.length < 4 || bytes[0] !== 0xFF || bytes[1] !== 0xD8) { return null; }
    var i = 2;
    while (i + 9 < bytes.length) {
      if (bytes[i] !== 0xFF) { i++; continue; }
      var m = bytes[i + 1];
      if (m === 0xFF) { i++; continue; }
      if (m === 0xD8 || m === 0x01 || (m >= 0xD0 && m <= 0xD7)) { i += 2; continue; }
      var len = (bytes[i + 2] << 8) | bytes[i + 3];
      if (m >= 0xC0 && m <= 0xCF && m !== 0xC4 && m !== 0xC8 && m !== 0xCC) {
        return { height: (bytes[i + 5] << 8) | bytes[i + 6], width: (bytes[i + 7] << 8) | bytes[i + 8], gray: bytes[i + 9] === 1 };
      }
      i += 2 + len;
    }
    return null;
  }

  window.SSPdf = { build: build, jpegInfo: jpegInfo };
})();
