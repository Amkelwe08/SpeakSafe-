/* Report page (students and staff, signed in).
   - Asks only: kind of abuse (optional), where, date, time, what happened, photos (optional).
   - Every report gets a SERIAL CODE. The person's identity (name, number, contact) is SEALED with Student Wellness'
     public key into an identity code that only Student Wellness can open (html/wellness.html, private key).
     So the report is private to everyone else, and known to the people who help.
   - "Send my report" posts the report (with a PDF copy attached) straight to the receiver's email, so nobody has
     to copy or retype anything. If that fails, the person can download the PDF or open an email instead.
   - The report text and photos are never stored. Only the serial code, date and kind are kept, locked with the login. */
(function () {
  "use strict";
  if (!window.SS) { return; }
  var SS = window.SS, V = SS.vault, CFG = SS.config || {}, INST = CFG.institution || {};

  var me = V.profile();
  if (!me) { window.location.replace("access.html?next=report.html"); return; }
  var roleCfg = (CFG.roles || {})[me.role] || { label: "Student", to: "wellness" };
  var rcpt = (CFG.recipients || {})[roleCfg.to] || {};
  var roleLabel = me.role === "staff" ? "Staff member" : "Student";

  function el(id) { return document.getElementById(id); }
  function val(id) { return el(id).value.trim(); }
  var form = el("reportForm"), errEl = el("rError"), sentBox = el("sentBox"), failBox = el("failBox");
  var codeEl = el("codeEl"), dateEl = el("rDate"), pdfBtn = el("pdfBtn"), failPdfBtn = el("failPdfBtn"), mailBtn = el("mailBtn");

  var attach = window.SSImages ? window.SSImages.attach({
    textarea: el("rText"), fileInput: el("rFile"), list: el("rThumbs"), errorEl: el("rImgErr"), max: 3
  }) : null;

  var serial = null, sealed = null;     // made once per visit, so a serial already sent never changes
  var current = null;                   // the prepared report (memory only)

  function todayISO() {
    var d = new Date();
    return d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
  }
  dateEl.max = todayISO();
  function prettyDate(iso) {
    var p = iso.split("-"), d = new Date(+p[0], +p[1] - 1, +p[2]);
    try { return d.toLocaleDateString("en-ZA", { day: "numeric", month: "long", year: "numeric" }); } catch (e) { return iso; }
  }

  function showError(msg, focusEl) { errEl.textContent = msg; errEl.hidden = false; if (focusEl) { focusEl.focus(); } }
  function clearError() { errEl.hidden = true; }
  form.addEventListener("input", clearError);
  form.addEventListener("change", clearError);

  /* ---------- serial code + sealed identity ---------- */
  function makeSerial() {
    var chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789", b = V.randomBytes(8), out = "";
    for (var i = 0; i < 8; i++) { out += chars.charAt(b[i] % chars.length); }
    return (INST.serialPrefix || "SS") + "-" + out.slice(0, 4) + "-" + out.slice(4);
  }
  function b64url(bytes) { return V.b64(bytes).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); }

  /* RSA-OAEP wraps a fresh AES key; AES-GCM seals the identity. Output: SW1.<wrapped key | iv | ciphertext> */
  function seal(payload) {
    if (!CFG.wellnessPublicKey) { return Promise.reject(new Error("nokey")); }
    var enc = new TextEncoder();
    return crypto.subtle.importKey("spki", V.unb64(CFG.wellnessPublicKey), { name: "RSA-OAEP", hash: "SHA-256" }, false, ["encrypt"])
      .then(function (rsa) {
        return crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, true, ["encrypt"]).then(function (aes) {
          var iv = V.randomBytes(12);
          return Promise.all([
            crypto.subtle.encrypt({ name: "AES-GCM", iv: iv }, aes, enc.encode(JSON.stringify(payload))),
            crypto.subtle.exportKey("raw", aes)
          ]).then(function (r) {
            return crypto.subtle.encrypt({ name: "RSA-OAEP" }, rsa, r[1]).then(function (wrapped) {
              var all = new Uint8Array(wrapped.byteLength + 12 + r[0].byteLength);
              all.set(new Uint8Array(wrapped), 0); all.set(iv, wrapped.byteLength); all.set(new Uint8Array(r[0]), wrapped.byteLength + 12);
              return "SW1." + b64url(all);
            });
          });
        });
      });
  }

  /* ---------- the report (one model for screen, PDF and email) ---------- */
  function gather() {
    var d = val("rDate"), t = val("rTime");
    var kind = form.querySelector('input[name="kind"]:checked');
    return {
      serial: serial, sealed: sealed, kind: kind ? kind.value : "",
      place: val("rPlace"), when: d ? prettyDate(d) + (t ? ", " + t : "") : t,
      text: val("rText"), prepared: prettyDate(todayISO()), images: attach ? attach.blobs().length : 0
    };
  }
  var REPORTER = roleLabel + ". Known to Student Wellness only through the serial code.";

  function rowsFor(r) {
    var rows = [["Serial code", r.serial], ["Prepared for", rcpt.label || "Student Wellness"], ["Date prepared", r.prepared], ["Reporter", REPORTER]];
    if (r.kind) { rows.push(["Kind of abuse", r.kind]); }
    rows.push(["Where it happened", r.place || "Not given"]);
    rows.push(["When it happened", r.when || "Not given"]);
    rows.push(["What happened", r.text]);
    rows.push(["Identity code (only " + (rcpt.label || "Student Wellness") + " can open this)", r.sealed, "small"]);
    return rows;
  }

  function pdfDoc(r) {
    return {
      code: r.serial,
      title: "Student Wellness report",
      subtitle: "Confidential. Prepared with SpeakSafe for " + (rcpt.label || "Student Wellness") + (INST.name ? " at " + INST.name : "") + ".",
      intro: "This report was prepared with SpeakSafe in the reporter's own words. The reporter is identified by the serial code and the sealed identity code below, which holds only their student or staff number. Only " + (rcpt.label || "Student Wellness") + " can open the identity code.",
      rows: rowsFor(r),
      closing: "Please treat this report as confidential. Use the serial code instead of the reporter's name in case notes and messages.",
      footer: "Prepared with SpeakSafe. Serial code " + r.serial + "."
    };
  }

  /* ---------- email (mailto) ---------- */
  function mailtoFor(r) {
    var subject = "Confidential report " + r.serial + " - via SpeakSafe";
    function body(story) {
      var lines = [
        rcpt.salutation || "Hello,", "",
        "I would like to make a report. Please use my serial code to find my details. The full report" + (r.images ? " (with my photos)" : "") + " is in the PDF attached to this email.", "",
        "Serial code: " + r.serial, "Reporter: " + roleLabel
      ];
      if (r.kind) { lines.push("Kind of abuse: " + r.kind); }
      lines.push("Where: " + (r.place || "Not given"), "When: " + (r.when || "Not given"), "",
        "Identity code (only Student Wellness can open this):", r.sealed, "",
        "What happened:", story, "", "Kind regards,", "Serial code " + r.serial);
      return lines.join("\r\n");
    }
    function url(story) {
      return "mailto:" + (rcpt.email ? encodeURIComponent(rcpt.email).replace("%40", "@") : "") +
        "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body(story));
    }
    var story = r.text, link = url(story), cut = story.length;
    while (link.length > 2000 && cut > 60) {      // some email apps limit link length; the PDF has the whole story
      cut = Math.floor(cut * 0.8);
      story = r.text.slice(0, cut).replace(/\s+\S*$/, "") + " ... (the rest is in the attached PDF)";
      link = url(story);
    }
    if (link.length > 2000) { link = url("(see the attached PDF)"); }
    return link;
  }

  /* ---------- your serial codes (locked list: code, date, kind only) ---------- */
  function renderLog() {
    V.load(SS.KEYS.reportLog).then(function (list) {
      var box = el("logBox"), ul = el("logList");
      ul.innerHTML = "";
      list.slice().reverse().forEach(function (it) {
        var li = document.createElement("li"), c = document.createElement("code");
        c.textContent = it.serial;
        li.appendChild(c);
        li.appendChild(document.createTextNode("  " + it.date + (it.kind ? " - " + it.kind : "")));
        ul.appendChild(li);
      });
      box.hidden = !list.length;
    }, function () {});
  }
  function remember(r) {
    return V.load(SS.KEYS.reportLog).then(function (list) {
      if (list.some(function (it) { return it.serial === r.serial; })) { return; }
      list.push({ serial: r.serial, date: r.prepared, kind: r.kind });
      return V.save(SS.KEYS.reportLog, list);
    }).then(renderLog, function () {});
  }
  renderLog();

  /* ---------- PDF ---------- */
  function readBytes(blob) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onload = function () { resolve(new Uint8Array(fr.result)); };
      fr.onerror = function () { reject(new Error("read")); };
      fr.readAsArrayBuffer(blob);
    });
  }
  function buildPdf(r) {
    var blobs = attach ? attach.blobs() : [];
    return Promise.all(blobs.map(readBytes)).then(function (list) {
      var images = [];
      list.forEach(function (bytes) {
        var info = window.SSPdf.jpegInfo(bytes);
        if (info && info.width && info.height) { images.push({ bytes: bytes, width: info.width, height: info.height, gray: info.gray }); }
      });
      return window.SSPdf.build(pdfDoc(r), images);
    });
  }
  function downloadPdf(btn) {
    if (!current || !window.SSPdf) { return; }
    btn.disabled = true;
    var old = btn.textContent; btn.textContent = "Making your PDF...";
    buildPdf(current).then(function (blob) {
      var url = URL.createObjectURL(blob), a = document.createElement("a");
      a.href = url; a.download = "SpeakSafe-report-" + current.serial + ".pdf";
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
      SS.toast("PDF downloaded");
    }).catch(function () { SS.toast("Could not make the PDF. Please try again."); })
      .then(function () { btn.disabled = false; btn.textContent = old; });
  }
  pdfBtn.addEventListener("click", function () { downloadPdf(pdfBtn); });
  failPdfBtn.addEventListener("click", function () { downloadPdf(failPdfBtn); remember(current); });

  /* ---------- automatic sending ---------- */
  function endpoint() {
    var d = CFG.delivery || {};
    if (d.endpoint) { return d.endpoint; }
    if (d.auto && rcpt.email) { return "https://formsubmit.co/ajax/" + encodeURIComponent(rcpt.email).replace("%40", "@"); }
    return "";
  }

  /* The report goes in one request, with the PDF attached. If the service refuses the attachment, send the text alone. */
  function deliver(r) {
    var url = endpoint();
    if (!url) { return Promise.reject(new Error("no-endpoint")); }
    return buildPdf(r).catch(function () { return null; }).then(function (pdf) {
      function post(withPdf) {
        var fd = new FormData();
        fd.append("_subject", "SpeakSafe report " + r.serial + (r.kind ? " (" + r.kind + ")" : ""));
        fd.append("_template", "table");
        fd.append("_captcha", "false");
        fd.append("Serial code", r.serial);
        fd.append("Prepared for", rcpt.label || "Student Wellness");
        fd.append("Reporter", roleLabel + " (known only through the serial code)");
        fd.append("Kind of abuse", r.kind || "Not given");
        fd.append("Where it happened", r.place || "Not given");
        fd.append("When it happened", r.when || "Not given");
        fd.append("What happened", r.text);
        fd.append("Photos", r.images ? (r.images + (withPdf && pdf ? " (inside the attached PDF)" : " (could not be attached)")) : "None");
        fd.append("Identity code (open it on the Student Wellness page)", r.sealed);
        if (withPdf && pdf) { fd.append("attachment", pdf, "SpeakSafe-report-" + r.serial + ".pdf"); }
        return fetch(url, { method: "POST", body: fd, headers: { Accept: "application/json" } }).then(function (res) {
          return res.json().catch(function () { return {}; }).then(function (j) {
            if (!res.ok || j.success === false || j.success === "false") { throw new Error("send"); }
          });
        });
      }
      return post(true).catch(function () { return post(false); });
    });
  }

  function showSent() {
    form.hidden = true; failBox.hidden = true; sentBox.hidden = false;
    codeEl.textContent = current.serial;
    var h = el("sentHeading"); h.setAttribute("tabindex", "-1"); h.focus({ preventScroll: true });
    sentBox.scrollIntoView({ behavior: "smooth", block: "start" });
  }
  function showFail() {
    form.hidden = true; sentBox.hidden = true; failBox.hidden = false;
    el("failCode").textContent = current.serial;
    var parts = [];
    if (!rcpt.email) { parts.push("No email address is set yet, so your email app will open with the To box empty."); }
    parts.push("Emails cannot carry photos automatically: attach the PDF you downloaded.");
    el("mailHint").textContent = parts.join(" ");
    var h = el("failHeading"); h.setAttribute("tabindex", "-1"); h.focus({ preventScroll: true });
    failBox.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function send() {
    var btn = el("sendBtn"), retry = el("retryBtn");
    btn.disabled = retry.disabled = true;
    var oldBtn = btn.textContent, oldRetry = retry.textContent;
    btn.textContent = retry.textContent = "Sending...";
    return deliver(current).then(function () {
      showSent(); return remember(current);
    }, function () { showFail(); })
      .then(function () { btn.disabled = retry.disabled = false; btn.textContent = oldBtn; retry.textContent = oldRetry; });
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var text = val("rText");
    if (text.length < 10) { showError("Please write at least a few words about what happened (10 characters or more).", el("rText")); return; }
    if (attach && attach.busy()) { showError("Please wait a moment while your photos finish loading."); return; }
    var d = val("rDate");
    if (d && d > todayISO()) { showError("The date cannot be in the future.", dateEl); return; }
    if (!el("rConsent").checked) { showError("Please tick the box to confirm that Student Wellness can identify you with your serial code.", el("rConsent")); return; }
    clearError();

    var btn = el("sendBtn"); btn.disabled = true;
    var ready = sealed ? Promise.resolve() : (function () {
      serial = makeSerial();
      return seal({ s: serial, r: me.role, n: me.num, i: me.inst, t: todayISO() }).then(function (x) { sealed = x; });
    })();
    ready.then(function () { current = gather(); btn.disabled = false; return send(); }, function () {
      serial = null; btn.disabled = false;
      showError("Could not prepare your report. Student Wellness' key is missing or invalid, so the report cannot be sealed. Please tell the person who set up SpeakSafe.");
    });
  });

  el("retryBtn").addEventListener("click", function () { if (current) { send(); } });
  el("editBtn").addEventListener("click", function () {
    failBox.hidden = true; form.hidden = false; el("rText").focus(); window.scrollTo({ top: 0, behavior: "smooth" });
  });

  /* ---------- fallback: email (mailto) ---------- */
  function mailtoFor(r) {
    var subject = "Confidential report " + r.serial + " - via SpeakSafe";
    function body(story) {
      var lines = [
        rcpt.salutation || "Hello,", "",
        "I would like to make a report. Please use my serial code to find my details. The full report" + (r.images ? " (with my photos)" : "") + " is in the PDF attached to this email.", "",
        "Serial code: " + r.serial, "Reporter: " + roleLabel
      ];
      if (r.kind) { lines.push("Kind of abuse: " + r.kind); }
      lines.push("Where: " + (r.place || "Not given"), "When: " + (r.when || "Not given"), "",
        "Identity code (only Student Wellness can open this):", r.sealed, "",
        "What happened:", story, "", "Kind regards,", "Serial code " + r.serial);
      return lines.join("\r\n");
    }
    function url(story) {
      return "mailto:" + (rcpt.email ? encodeURIComponent(rcpt.email).replace("%40", "@") : "") +
        "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body(story));
    }
    var story = r.text, link = url(story), cut = story.length;
    while (link.length > 2000 && cut > 60) {      // some email apps limit link length; the PDF has the whole story
      cut = Math.floor(cut * 0.8);
      story = r.text.slice(0, cut).replace(/\s+\S*$/, "") + " ... (the rest is in the attached PDF)";
      link = url(story);
    }
    if (link.length > 2000) { link = url("(see the attached PDF)"); }
    return link;
  }
  mailBtn.addEventListener("click", function () {
    if (!current) { return; }
    var a = document.createElement("a");        // a real link click opens the email app and keeps this page open
    a.href = mailtoFor(current);
    document.body.appendChild(a); a.click(); a.remove();
    SS.toast("Opening your email app. Attach the PDF, then press Send.");
    remember(current);
  });

  el("copyBtn").addEventListener("click", function () {
    var text = codeEl.textContent;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () { SS.toast("Code copied"); }, function () { SS.toast("Could not copy. Please write it down."); });
    } else { SS.toast("Please write the code down."); }
  });
})();
