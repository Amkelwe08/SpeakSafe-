(function () {
  "use strict";
  var tabs = [document.getElementById("tab-student"), document.getElementById("tab-worker")];
  if (!tabs[0] || !tabs[1]) { return; }

  function select(i) {
    tabs.forEach(function (t, idx) {
      var on = idx === i;
      t.setAttribute("aria-selected", on ? "true" : "false");
      document.getElementById(t.getAttribute("aria-controls")).hidden = !on;
    });
  }
  tabs.forEach(function (t, i) {
    t.addEventListener("click", function () { select(i); });
    t.addEventListener("keydown", function (e) {
      if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
        var n = (i + 1) % 2; select(n); tabs[n].focus();
      }
    });
  });
})();
