/* Student Wellness tool. Runs only in the browser. The private key is never uploaded or stored.
   Opens "SW1." identity codes made by the report page (RSA-OAEP wrapped AES-GCM key). */
(function () {
  "use strict";
  function $(id) { return document.getElementById(id); }
  var errEl = $("wError");
  function showErr(m) { errEl.textContent = m; errEl.hidden = false; }
  function clearErr() { errEl.hidden = true; }

  function unb64(s) { var b = atob(s), o = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) { o[i] = b.charCodeAt(i); } return o; }
  function unb64url(s) { s = s.replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) { s += "="; } return unb64(s); }
  function b64(buf) { var s = "", b = new Uint8Array(buf); for (var i = 0; i < b.length; i++) { s += String.fromCharCode(b[i]); } return btoa(s); }
  function pemToDer(pem) { return unb64(pem.replace(/-----[^-]+-----/g, "").replace(/\s+/g, "")); }

  $("keyFile").addEventListener("change", function () {
    var f = this.files && this.files[0]; if (!f) { return; }
    var fr = new FileReader();
    fr.onload = function () { $("privKey").value = String(fr.result); clearErr(); };
    fr.readAsText(f);
  });

  function row(dl, k, v) {
    var dt = document.createElement("dt"), dd = document.createElement("dd");
    dt.textContent = k; dd.textContent = v || "Not given"; dl.appendChild(dt); dl.appendChild(dd);
  }

  $("openBtn").addEventListener("click", function () {
    clearErr(); $("wResult").hidden = true;
    if (!(window.crypto && crypto.subtle)) { showErr("This page needs a secure connection (https) or localhost."); return; }
    var pem = $("privKey").value.trim(), m = $("sealedCode").value.match(/SW1\.[A-Za-z0-9_-]+/);
    if (!pem) { showErr("Add your private key first."); return; }
    if (!m) { showErr("Paste the identity code from the report (it starts with SW1.)."); return; }
    var bytes;
    try { bytes = unb64url(m[0].slice(4)); } catch (e) { showErr("That identity code looks damaged."); return; }
    var wrapped = bytes.slice(0, 256), iv = bytes.slice(256, 268), ct = bytes.slice(268);

    crypto.subtle.importKey("pkcs8", pemToDer(pem), { name: "RSA-OAEP", hash: "SHA-256" }, false, ["decrypt"])
      .then(function (priv) { return crypto.subtle.decrypt({ name: "RSA-OAEP" }, priv, wrapped); })
      .then(function (raw) { return crypto.subtle.importKey("raw", raw, { name: "AES-GCM" }, false, ["decrypt"]); })
      .then(function (aes) { return crypto.subtle.decrypt({ name: "AES-GCM", iv: iv }, aes, ct); })
      .then(function (pt) {
        var p = JSON.parse(new TextDecoder().decode(pt)), dl = $("wSummary");
        dl.innerHTML = "";
        row(dl, "Serial code", p.s);
        row(dl, "Is a", p.r === "staff" ? "Staff member" : "Student");
        row(dl, p.r === "staff" ? "Staff number" : "Student number", p.n);
        row(dl, "Institution", p.i); row(dl, "Report made on", p.t);
        $("wResult").hidden = false; $("wResult").scrollIntoView({ behavior: "smooth", block: "start" });
      })
      .catch(function () { showErr("Could not open it. Check that you pasted the right private key and the whole identity code."); });
  });

  /* make a new key pair */
  var priv = "";
  $("genBtn").addEventListener("click", function () {
    if (!(window.crypto && crypto.subtle)) { showErr("This page needs a secure connection (https) or localhost."); return; }
    crypto.subtle.generateKey({ name: "RSA-OAEP", modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: "SHA-256" }, true, ["encrypt", "decrypt"])
      .then(function (kp) { return Promise.all([crypto.subtle.exportKey("spki", kp.publicKey), crypto.subtle.exportKey("pkcs8", kp.privateKey)]); })
      .then(function (r) {
        $("pubOut").value = b64(r[0]);
        priv = "-----BEGIN PRIVATE KEY-----\n" + b64(r[1]).match(/.{1,64}/g).join("\n") + "\n-----END PRIVATE KEY-----\n";
        $("genOut").hidden = false;
      });
  });
  $("dlPriv").addEventListener("click", function () {
    if (!priv) { return; }
    var url = URL.createObjectURL(new Blob([priv], { type: "text/plain" })), a = document.createElement("a");
    a.href = url; a.download = "student-wellness-private-key.pem"; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
  });
})();
